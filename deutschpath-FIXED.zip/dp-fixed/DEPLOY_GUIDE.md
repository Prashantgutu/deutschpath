# DeutschPath — Fixed Deployment Guide

## Folder structure (keep exactly like this)

```
deutschpath/
├── api/
│   └── chat.js       ← AI chatbot backend
├── index.html        ← Website (must be at ROOT, not in any folder)
├── vercel.json       ← Simple config
└── package.json
```

---

## How to re-deploy (fix the issue)

### If you used GitHub:

1. Delete all files from your GitHub repo
2. Upload the new files from this ZIP (keeping the same folder structure above)
3. Vercel will auto-redeploy — wait 1–2 minutes
4. Open your Vercel URL again

### If you used Vercel CLI:

1. Replace your project files with these new ones
2. Run: `npx vercel --prod`

---

## Add your API key (REQUIRED for chatbot)

1. Go to https://vercel.com → your project
2. Click **Settings** → **Environment Variables**
3. Click **Add New**:
   - Name:  `ANTHROPIC_API_KEY`
   - Value: `sk-ant-...` (your key from console.anthropic.com)
   - Tick: Production + Preview + Development
4. Click **Save**
5. Go to **Deployments** tab → click the 3 dots on the latest → **Redeploy**

---

## Test if it's working

After deploy, open your site URL and:
1. The website should load with the dark navy design
2. Scroll to **AI Assistant** at the bottom
3. Type: "What visa do I need for Germany?"
4. You should get a reply within 5 seconds

---

## Common errors

| Problem | Fix |
|---|---|
| White blank page | Make sure `index.html` is at the ROOT, not inside a `public` folder |
| Chatbot says "API key not configured" | Add `ANTHROPIC_API_KEY` in Vercel Environment Variables, then Redeploy |
| Chatbot says "Server error" | Check that your API key is correct and starts with `sk-ant-` |
| 404 on the page | Make sure `vercel.json` is in the root folder |

---

## Get Anthropic API key

1. Go to https://console.anthropic.com
2. Sign up (free)
3. Click **API Keys** → **Create Key**
4. Copy the key immediately (only shown once!)
