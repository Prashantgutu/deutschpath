# DeutschPath — Deployment Guide

## What's in this package

```
deutschpath/
├── api/
│   └── chat.js          ← AI chatbot backend (uses your Anthropic API key securely)
├── public/
│   └── index.html       ← Full website (Hindi/English, quiz, tutors, loan, chatbot)
├── vercel.json          ← Hosting config
├── package.json         ← Project info
└── README.md            ← This file
```

---

## Step 1 — Get a free Anthropic API key

1. Go to https://console.anthropic.com
2. Sign up / log in
3. Click **API Keys** → **Create Key**
4. Copy the key (starts with `sk-ant-...`)
5. Keep it safe — you'll need it in Step 3

---

## Step 2 — Deploy to Vercel (free)

### Option A — Using GitHub (recommended)

1. Create a free account at https://github.com
2. Create a new repository called `deutschpath`
3. Upload all files from this folder to the repo
4. Go to https://vercel.com → **Sign Up** (use your GitHub account)
5. Click **Add New Project** → Import your `deutschpath` repo
6. Click **Deploy** — Vercel handles everything automatically

### Option B — Using Vercel CLI

1. Install Node.js from https://nodejs.org (LTS version)
2. Open Terminal / Command Prompt in this folder
3. Run: `npm install`
4. Run: `npx vercel login`
5. Run: `npx vercel --prod`
6. Follow the prompts

---

## Step 3 — Add your Anthropic API key (required for chatbot)

1. Go to https://vercel.com → your project → **Settings** → **Environment Variables**
2. Click **Add New**
3. Name: `ANTHROPIC_API_KEY`
4. Value: `sk-ant-...` (paste your key from Step 1)
5. Environment: tick **Production**, **Preview**, and **Development**
6. Click **Save**
7. Go to **Deployments** → click **Redeploy** on the latest deployment

**That's it!** Your chatbot will now work on the live site.

---

## Step 4 — Custom domain (optional)

1. Go to Vercel project → **Settings** → **Domains**
2. Add your domain (e.g. `deutschpath.in`)
3. Follow DNS instructions — takes ~10 minutes to go live

---

## Customising the website

### Change contact info
Open `public/index.html` and search for:
- `info@deutschpath.in` — replace with your email
- `+91 98765 43210` — replace with your phone number
- `Delhi · Mumbai · Bangalore` — replace with your cities

### Change tutor names/prices
In `public/index.html`, find the `TUTORS` array (around line 200) and edit:
```javascript
const TUTORS = [
  { name: "Your Tutor Name", price: "₹800/hr", ... },
  ...
];
```

### Change loan amounts / bank partners
Find the `loanPts` arrays in both `EN` and `HI` objects and edit the text.

### Change the AI chatbot personality
Open `api/chat.js` and edit the `system:` text to change how the AI responds.

---

## Testing locally

1. Install Node.js from https://nodejs.org
2. Open Terminal in this folder
3. Run: `npm install`
4. Create a file called `.env` in the root folder with:
   ```
   ANTHROPIC_API_KEY=sk-ant-your-key-here
   ```
5. Run: `npx vercel dev`
6. Open http://localhost:3000 in your browser

---

## Need help?

Email: support@deutschpath.in
WhatsApp: +91 98765 43210

---

*Built with Claude AI · Powered by Anthropic*
